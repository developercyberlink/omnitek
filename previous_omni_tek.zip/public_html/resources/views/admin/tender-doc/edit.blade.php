@extends('admin.master')
@section('title','Post')

@section('breadcrumb')
<a href="#">List</a>
@endsection

@section('content')


@endsection