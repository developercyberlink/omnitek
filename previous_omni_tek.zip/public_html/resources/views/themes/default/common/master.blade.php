@include('themes.default.common.header')
@include('themes.default.common.security-header')

@yield('content')
@include('themes.default.common.footer')