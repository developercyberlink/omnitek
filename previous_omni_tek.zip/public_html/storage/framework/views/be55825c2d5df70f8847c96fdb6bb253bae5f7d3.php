<?php $__env->startSection('post_title',$data->post_title); ?>
<?php $__env->startSection('meta_keyword',$data->meta_keyword); ?>
<?php $__env->startSection('meta_description',$data->meta_description); ?>
<?php $__env->startSection('content'); ?>
    <!-- header -->
    <section
        class="uk-cover-container  uk-position-relative uk-flex uk-flex-middle uk-background-norepeat uk-background-cover"
        style="background:url(<?php echo e(asset('uploads/original/' . $data->banner)); ?>);">
        <div class="uk-overlay-primary  uk-position-cover "></div>
        <div class="uk-home-banner uk-width-1-1 uk-position-z-index"
             uk-scrollspy="cls: uk-animation-slide-top-small; target:a, li, h1, p;  delay: 100; repeat: false;">
            <div class="uk-container uk-container-large uk-position-relative text-white uk-flex-middle uk-flex"
                 uk-height-viewport="expand: true; min-height: 400;">
                <div class="uk-width-1-2@m uk-text-left">
                    <div class="uk-light">
                        <ul class="uk-breadcrumb">
                            <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
                            <li><span><?php echo e($data->post_type); ?></span></li>
                        </ul>
                    </div>
                    <h1 class="uk-h1 uk-text-bold text-white uk-margin-small"><?php echo e($data->post_type); ?></h1>
                </div>
            </div>
        </div>
    </section>
    <!-- end header -->
    <!-- section -->
    <section class="uk-section bg-pattern-02 uk-blog-list">
        <div class="uk-container uk-container-large"
             uk-scrollspy="cls: uk-animation-slide-top-small; target:div, h1, a;  delay: 100; repeat: false;">
            <!-- news block -->
            <div class="uk-grid-medium" uk-grid>
                <!--  -->
                <?php $__currentLoopData = $posts->take(1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="uk-width-expand@m">
                        <a href="<?php echo e(url(geturl($row['uri'],$row['page_key']))); ?>" class="uk-article-list">
                            <div class="uk-article-list-image"
                                 style="background-image: url(<?php echo e(asset('uploads/original/' . $row->page_thumbnail)); ?>);">
                                <div class="uk-article-category">
                                    <?php echo e(show_category($row->post_category)); ?>

                                </div>
                                <div class="uk-article-dec">
                                    <h1 class="uk-h4 uk-text-normal uk-margin-remove text-white"><?php echo e($row->post_title); ?></h1>
                                </div>
                            </div>
                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <!--  -->
                <!--  -->
                <?php $__currentLoopData = $posts->skip(1)->take(2); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="uk-width-1-4@m">
                        <a href="<?php echo e(url(geturl($row['uri'],$row['page_key']))); ?>" class="uk-article-list">
                            <div class="uk-article-list-image"
                                 style="background-image: url(<?php echo e(asset('uploads/original/' . $row->page_thumbnail)); ?>);">
                                <div class="uk-article-category"><?php echo e(show_category($row->post_category)); ?></div>
                                <div class="uk-article-dec">
                                    <h1 class="uk-h4 uk-text-normal uk-margin-remove text-white">
                                        <?php echo e($row->post_title); ?>

                                    </h1>
                                </div>
                            </div>
                        </a>
                    </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <!--  -->

                <!--  -->
            </div>
            <!-- news block -->
            <!--  -->
            <ul class="uk-grid-medium uk-child-width-1-3@m uk-child-width-1-2@s uk-child-width-1-2@s"
                uk-height-match="target:.uk-same-height" uk-grid>
                <!--  -->
                <?php $__currentLoopData = $posts->skip(3)->take(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <li>
                        <div class=" bg-white uk-box-shadow-medium uk-article-list">
                            <?php if($row->external_link): ?>
                                <div class="open-video" data-youtube-id="<?php echo e($row->external_link); ?>">
                                    <div class="uk-media-250 uk-position-relative uk-same-height">
                                        <div class="uk-overlay-primary uk-position-cover"></div>
                                        <div class="uk-position-center-top">
                                            <div
                                                class="uk-article-category bg-primary"><?php echo e(show_category($row->post_category)); ?></div>
                                        </div>
                                        <img src="https://img.youtube.com/vi/<?php echo e($row->external_link); ?>/maxresdefault.jpg">
                                        <div class="uk-position-center uk-zindex">
                                            <i class="fa fa-play fa-2x text-white"></i>
                                        </div>
                                    </div>
                                </div>
                            <?php else: ?>
                                <div class="uk-media-250 uk-position-relative">
                                    <a href="<?php echo e(url(geturl($row['uri'],$row['page_key']))); ?>">
                                        <div class="uk-overlay-primary uk-position-cover"></div>
                                        <div class="uk-position-center-top">
                                            <div
                                                class="uk-article-category bg-primary"><?php echo e(show_category($row->post_category)); ?></div>
                                        </div>
                                        <img src="<?php echo e(asset('uploads/original/' . $row->page_thumbnail)); ?>">
                                    </a>
                                </div>
                        <?php endif; ?>
                        <!-- if video -->
                            <div class=" uk-padding uk-same-height">
                                <h1 class="f-20 f-w-400 uk-margin-remove"><a
                                        href="<?php echo e(url(geturl($row['uri'],$row['page_key']))); ?>"><?php echo e($row->post_title); ?></a>
                                </h1>
                            </div>
                        </div>
                    </li>

                    <!--  -->
                
                

                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                <!--  -->
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <!--  -->


            </ul>
            <!--  -->
        </div>
    </section>
    <!-- section -->
    <nav>
        <ul class="pagination">
            <?php echo e($posts->links()); ?>


        </ul>
    </nav>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('themes.default.common.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/omnitek/public_html/resources/views/themes/default/posttypeTemplate-blog-list.blade.php ENDPATH**/ ?>