<?php echo $__env->make('themes.default.common.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php if(Illuminate\Support\Facades\Session::has('message')): ?>
    <div class="alert alert-block alert-success alert-dismissible" style="color:green">
        <p class="alert alert-success"><?php echo e(Session::get('message')); ?></p>
    </div>
<?php endif; ?>

<?php if($errors->any()): ?>
    <div class="alert alert-danger" style="color:red">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<?php echo $__env->yieldContent('content'); ?>
<?php echo $__env->make('themes.default.common.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<script type="text/javascript">
    // import {alert} from "../../../../../public/assets/js/utility/utility";

    $(document).ready(function () {
        $('.alert').hide(8000);
    });

    $(document).ready(function () {

        $('.publication_filter').change(function (e) {
            var val = $(this).find(':checked').val();
            console.log(val);

            $.ajax({
                url: document.URL,
                type: 'get',
                data: {
                    value: val,
                },
                success: function (result) {
                    console.log(result);

                    $('.filter_result').replaceWith($('.filter_result')).html(result);
                }
            });

        })


    });

</script>
<?php /**PATH /home/omnitek/public_html/resources/views/themes/default/common/master.blade.php ENDPATH**/ ?>