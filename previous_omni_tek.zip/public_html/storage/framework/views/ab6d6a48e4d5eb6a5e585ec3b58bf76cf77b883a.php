<?php $__env->startSection('post_title',$data->post_title); ?>
<?php $__env->startSection('meta_keyword',$data->meta_keyword); ?>
<?php $__env->startSection('meta_description',$data->meta_description); ?>
<?php $__env->startSection('content'); ?>
    <!-- section -->
    <section class="uk-section uk-position-relative">
        <div class="uk-container uk-container-large uk-position-relative">
            <div class="uk-grid-large" uk-grid
                 uk-scrollspy="cls: uk-animation-slide-top-small; target:div, p, h1, h2, h3, h4, h5, h6, a;  delay: 50; repeat: false;">
                <div class="uk-width-expand@m">
                    <h1 class="uk-h2 f-w-600 uk-margin"><?php echo e($data->post_title); ?></h1>
                    <!--  -->
                    <div class="uk-border-light-top uk-border-light-bottom uk-margin-bottom uk-padding-small">
                        <div class="uk-child-width-expand@s uk-flex-middle" uk-grid>
                            <div class="uk-text-muted"><i
                                    class="fa fa-clock-o"></i> <?php echo e($data->updated_at->format('d M Y')); ?></div>
                            <div>
                                <!-- ShareThis BEGIN -->
                                <div class="sharethis-inline-share-buttons"></div>
                                <!-- ShareThis END -->
                            </div>
                        </div>
                    </div>

                    <!--if video -->
                    <?php if($data->external_link): ?>
                        <figure class="uk-feature-video uk-margin-medium-bottom">
                            <iframe width="100%" height="500"
                                    src="https://www.youtube.com/embed/<?php echo e($data->external_link); ?>"
                                    title="YouTube video player" frameborder="0"
                                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                                    allowfullscreen></iframe>
                            <figcaption class="f-14"><?php echo e($data->post_title); ?></figcaption>
                        </figure>
                    <?php else: ?>
                    <!--  -->
                        <figure class="uk-feature-image uk-margin-medium-bottom" uk-lightbox="">
                            <a href="<?php echo e(asset('uploads/original/' . $data->banner)); ?>"
                               data-caption="<?php echo e($data->post_title); ?>">
                                <img src="<?php echo e(asset('uploads/original/' . $data->banner)); ?>" alt=""> </a>
                            <figcaption class="f-14"><?php echo e($data->post_title); ?></figcaption>
                        </figure>
                    <?php endif; ?>
                <!-- end if video -->
                    <?php echo $data->post_content; ?>


                </div>
                <div class="uk-width-1-3@l">
                    <h1 class="uk-h4 f-w-600">Related</h1>
                    <!--  -->
                    <ul class="uk-grid-medium uk-child-width-1-1 uk-blog-list" uk-height-match="target:.uk-same-height"
                        uk-grid>
                        <!--  -->
                        <?php $__currentLoopData = $related; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($value->uri != $data->uri): ?>
                            <?php if($value->external_link): ?>
                                <li>
                                    <div class=" bg-white uk-box-shadow-medium uk-article-list">
                                        <div class="open-video" data-youtube-id="<?php echo e($value->external_link); ?>">
                                            <div class="uk-media-250 uk-position-relative uk-same-height">
                                                <div class="uk-overlay-primary uk-position-cover"></div>
                                                <div class="uk-position-center-top">
                                                    <div
                                                        class="uk-article-category bg-primary"><?php echo e(show_category($value->post_category)); ?></div>
                                                </div>
                                                <img
                                                    src="https://img.youtube.com/vi/<?php echo e($value->external_link); ?>/maxresdefault.jpg">
                                                <div class="uk-position-center uk-zindex">
                                                    <i class="fa fa-play fa-2x text-white"></i>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- if video -->
                                        <div class=" uk-padding uk-same-height">
                                            <h1 class="f-20 f-w-400 uk-margin-remove"><a
                                                    href="<?php echo e(url(geturl($value['uri'],$value['page_key']))); ?>">
                                                    <?php echo e($value->post_title); ?>

                                                </a></h1>
                                        </div>
                                    </div>
                                </li>
                            <?php else: ?>
                                <li>
                                    <div class="bg-white uk-box-shadow-medium uk-article-list">
                                        <div class="uk-media-250 uk-position-relative">
                                            <a href="<?php echo e(url(geturl($value['uri'],$value['page_key']))); ?>">
                                                <div class="uk-overlay-primary uk-position-cover"></div>
                                                <div class="uk-position-center-top">
                                                    <div
                                                        class="uk-article-category bg-primary"><?php echo e(show_category($value->post_category)); ?></div>
                                                </div>
                                                <img src="<?php echo e(asset('uploads/original/' . $value->page_thumbnail)); ?>">
                                            </a>
                                        </div>
                                        <div class="uk-position-relative  uk-padding uk-same-height">
                                            <h1 class="f-20 f-w-400 uk-margin-remove"><a
                                                    href="<?php echo e(url(geturl($value['uri'],$value['page_key']))); ?>">
                                                    <?php echo e($value->post_title); ?>

                                                </a></h1>
                                        </div>
                                    </div>
                                </li>
                        <?php endif; ?>
                            <?php endif; ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <!--  -->
                        <!--  -->
                        <!--  -->
                    </ul>
                    <!--  -->
                </div>
            </div>
        </div>
    </section>
    <!-- section end -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('themes.default.common.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/omnitek/public_html/resources/views/themes/default/template-blog-single.blade.php ENDPATH**/ ?>