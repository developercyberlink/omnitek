<?php $__env->startSection('post_title',$data->post_title); ?>
<?php $__env->startSection('meta_keyword',$data->meta_keyword); ?>
<?php $__env->startSection('meta_description',$data->meta_description); ?>
<?php $__env->startSection('content'); ?>
    <!-- banner -->
    <section class="bg-primary uk-background-norepeat uk-background-top-right uk-background-image@s
   uk-position-relative uk-flex uk-flex-middle uk-text-left"
             uk-height-viewport="expand: true; min-height: 150;">
        <div class="uk-width-1-1 uk-position-z-index">
            <div class="uk-container text-white"
                 uk-scrollspy="cls: uk-animation-slide-top-small; target:h2;  delay: 100; repeat: false;">
                <h2 class="f-30 f-w-600  uk-margin-small"><?php echo e($data->post_title); ?></h2>
            </div>
        </div>
    </section>
    <!-- end banner -->
    <!-- section -->
    <section class="uk-section bg-light">
        <div class="uk-container"
             uk-scrollspy="cls: uk-animation-slide-top-small; target:div, h1, a;  delay: 50; repeat: false;">

            <!--  -->
            <!--  -->
            <ul class="uk-grid-medium uk-child-width-1-3@m uk-child-width-1-2@s uk-child-width-1-2@s"
                uk-height-match="target:.uk-same-height" uk-grid>
                <!--  -->
                <!--  -->

                <?php if($data_child->count()>0): ?>
                    <?php $__currentLoopData = $data_child; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($row->external_link): ?>
                            <li>
                                <div class=" bg-white uk-box-shadow-medium uk-bordered-rounded uk-overflow-hidden">

                                    <div class="open-video" data-youtube-id="<?php echo e($row->external_link); ?>">
                                        <div
                                            class="uk-media-250 uk-position-relative uk-pointer-left uk-pointer-left-primary uk-same-height">
                                            <div class="uk-overlay-primary uk-position-cover"></div>
                                            <img
                                                src="https://img.youtube.com/vi/<?php echo e($row->external_link); ?>/maxresdefault.jpg">
                                            <div class="uk-position-center uk-zindex">
                                                <i class="fa fa-play fa-2x text-white"></i>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- if video -->
                                    <div class="uk-border-left-on-hover uk-padding uk-same-height">
                            <span
                                class="uk-display-block uk-text-muted f-14 f-w-400 uk-margin-small-bottom"><?php echo e($row->updated_at->format('d M Y')); ?></span>
                                        <h1 class="f-20 f-w-400 uk-margin-remove"><a
                                                href="<?php echo e(url(geturl($row['uri'],$row['page_key']))); ?>">
                                                <?php echo e($row->post_title); ?></a></h1>
                                    </div>
                                </div>
                            </li>
                        <?php else: ?>
                            <li>
                                <div class="bg-white uk-box-shadow-medium uk-bordered-rounded uk-overflow-hidden ">
                                    <div class="uk-media-250 uk-position-relative">
                                        <a href="<?php echo e(url(geturl($row['uri'],$row['page_key']))); ?>">
                                            <img src="<?php echo e(asset('uploads/original/' . $row->page_thumbnail)); ?>">
                                        </a>
                                    </div>
                                    <div class="uk-position-relative uk-border-left-on-hover uk-padding uk-same-height">
                                    <span
                                        class="uk-display-block uk-text-muted f-14 f-w-400 uk-margin-small-bottom"><?php echo e($row->updated_at->format('d M Y')); ?></span>
                                        <h1 class="f-20 f-w-400 uk-margin-remove"><a
                                                href="<?php echo e(url(geturl($row['uri'],$row['page_key']))); ?>"><?php echo e($row->post_title); ?></a>
                                        </h1>
                                    </div>
                                </div>
                            </li>
                    <?php endif; ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            <!--  -->

            </ul>
            <!--  -->
        </div>
    </section>
    <!-- section -->
    <nav>
        <ul class="pagination">
            <?php echo e($data_child->links()); ?>


        </ul>
    </nav>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('themes.default.common.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/omnitek/public_html/resources/views/themes/default/template-media-list.blade.php ENDPATH**/ ?>