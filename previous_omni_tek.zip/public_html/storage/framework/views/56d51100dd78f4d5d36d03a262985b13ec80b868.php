<!-- start offcanvas menu -->
<div id="offcanvas-reveal" uk-offcanvas="flip: true;  overlay: true;">
    <div
        class="uk-offcanvas-bar uk-dark uk-offcanvas-bar-white uk-padding-remove  uk-box-shadow-medium uk-flex uk-flex-between uk-flex-column">
        <div class=" uk-padding-small uk-border-bottom">
            <div class="uk-flex uk-flex-between uk-flex-middle uk-flex text-black">
                <div>
                    <?php echo e($setting->site_name); ?>

                </div>
                <div>
                    <button class="uk-offcanvas-close uk-close-large text-red" type="button" uk-close></button>
                </div>
            </div>
        </div>
        <div>

            <nav>
                <ul class="uk-navsidebar    uk-nav-parent-icon uk-nav-left  " uk-nav="multiple: false">
                    <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
                    <?php if($navigations->count() > 0): ?>
                        <?php $__currentLoopData = $navigations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($row->id==40): ?>
                                <li class="uk-parent uk-open">
                                    <a href="<?php echo e(url('page/' . posttype_url($row->uri))); ?>"><?php echo e($row->post_type); ?></a>
                                    <ul class="uknavsub">
                                        <?php $__currentLoopData = getposts($row->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li>
                                                <a href="<?php echo e(url(geturl($value['uri'], $value['page_key']))); ?>"><?php echo e($value->post_title); ?></a>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </li>
                            <?php else: ?>
                                <li>
                                    <a href="<?php echo e(url('page/' . posttype_url($row->uri))); ?>"><?php echo e($row->post_type); ?>                                    </a>
                                </li>
                            <?php endif; ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </ul>
            </nav>
        </div>
        <!-- social icon -->
        <div class="uk-position-relative">
            <div>
                <div class="uk-padding-small uk-border-top">
                    <ul class="uk-grid-small  uk-flex-center" uk-grid>
                        <li><a class="facebookBtn smGlobalBtn" href="<?php echo e($setting->facebook_link); ?>"></a></li>
                        
                        <li><a class="twitterBtn smGlobalBtn" href="<?php echo e($setting->twitter_link); ?>"></a></li>
                        
                        
                    </ul>
                </div>
                <div class="uk-padding-small uk-border-top">
                    <div class="f-15 uk-margin-remove uk-text-left@s uk-text-center text-black">Contact at</div>
                    <div class="f-20 uk-margin-remove uk-text-left@s uk-text-center text-primary">
                        <?php echo e($setting->phone); ?>

                    </div>
                </div>
            </div>
        </div>
        <!-- end social icon -->
    </div>
</div>
<!-- end offcanvas menu -->
<?php /**PATH /home/omnitek/public_html/resources/views/themes/default/common/offcanvas-menu.blade.php ENDPATH**/ ?>